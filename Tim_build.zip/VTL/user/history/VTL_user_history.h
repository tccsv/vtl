#ifndef _VTL_USER_HISTORY_H
#define _VTL_USER_HISTORY_H

#ifdef __cplusplus
extern "C"
{
#endif


#include <VTL/user/history/db/VTL_user_history_save.h>
#include <VTL/user/history/db/VTL_user_history_credentals.h>
#include <VTL/user/history/VTL_user_history_data.h>


#ifdef __cplusplus
}
#endif


#endif