#include <VTL/user/history/db/VTL_user_history_credentals.h>

VTL_AppResult VTL_user_history_credentals_Init(VTL_db_Credentals* p_credentals)
{
    return VTL_res_kOk;
}