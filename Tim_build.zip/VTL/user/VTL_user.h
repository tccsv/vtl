#ifndef _VTL_USER_H
#define _VTL_USER_H

#ifdef __cplusplus
extern "C"
{
#endif



#include <VTL/user/VTL_user_data.h>
#include <VTL/user/history/VTL_user_history.h>


#ifdef __cplusplus
}
#endif


#endif