#include <VTL/utils/VTL_encryptor.h>

void VTL_Encrypt(const VTL_StandartString src_string, VTL_EncryptedString encrypted_string)
{
    return;
}