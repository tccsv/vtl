#include <VTL/utils/db/VTL_db_credentals.h>

VTL_AppResult VTL_db_credentals_Zeroize(VTL_db_Credentals* p_credentals)
{
    return VTL_res_kOk;
}