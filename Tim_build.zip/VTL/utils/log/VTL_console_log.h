#ifndef _VTL_CONSOLE_LOG_H
#define _VTL_CONSOLE_LOG_H

#ifdef __cplusplus
extern "C"
{
#endif

#include <VTL/VTL_app_result.h>
#include <stdio.h>

 

void VTL_console_out_PotencialErr(VTL_AppResult app_result);

#ifdef __cplusplus
}
#endif


#endif