#ifndef _VTL_USER_HISTORY_ADMINISTRATION_CREATE_H
#define _VTL_USER_HISTORY_ADMINISTRATION_CREATE_H

#ifdef __cplusplus
extern "C"
{
#endif





#ifdef __cplusplus
}
#endif


#endif