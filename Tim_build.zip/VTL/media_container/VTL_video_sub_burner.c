#include <VTL/media_container/VTL_video_sub_burner.h>

VTL_AppResult VTL_video_sub_BurnIn(VTL_Filename video_file_name, VTL_Sub sub)
{
    return VTL_res_kOk;
}