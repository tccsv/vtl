#include <VTL/media_container/audio/infra/VTL_audio_read.h>

VTL_AppResult VTL_audio_OpenOutput(VTL_audio_File** pp_outputs, const VTL_Filename output_name)
{
    return VTL_res_kOk;
}

VTL_AppResult VTL_audio_WritePart(const VTL_audio_Data* p_audio_part, VTL_audio_File* p_outputs)
{
    return VTL_res_kOk;
}

VTL_AppResult VTL_audio_CloseOutput(VTL_audio_File* p_outputs)
{
    return VTL_res_kOk;
}