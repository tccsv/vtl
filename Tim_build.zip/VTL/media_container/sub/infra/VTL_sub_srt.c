#include <VTL/media_container/sub/infra/VTL_sub_srt.h>

VTL_AppResult VTL_sub_srt_Conversion(VTL_Sub** pp_sub, const char* p_raw_srt_data, size_t data_size)
{
    return VTL_res_kOk;
}
