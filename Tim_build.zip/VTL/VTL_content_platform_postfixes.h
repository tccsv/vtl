#ifndef _VTL_CONTENT_PLATFORM_POSTFIXES_H
#define _VTL_CONTENT_PLATFORM_POSTFIXES_H

#ifdef __cplusplus
extern "C"
{
#endif

#define VTL_CONTENT_PLATFORM_W_POSTFIX "w"
#define VTL_CONTENT_PLATFORM_TG_POSTFIX "tg"


#ifdef __cplusplus
}
#endif


#endif