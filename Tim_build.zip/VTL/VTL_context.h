#ifndef _VTL_CONTEXT_H
#define _VTL_CONTEXT_H

#ifdef __cplusplus
extern "C"
{
#endif


#include <VTL/utils/VTL_file.h>


typedef struct _VTL_Context 
{
    VTL_Filename video_src_file_name;
    
    
} VTL_Context;




#ifdef __cplusplus
}
#endif


#endif