#ifndef _VTL_PUBLICATION_TEXT_H
#define _VTL_PUBLICATION_TEXT_H

#ifdef __cplusplus
extern "C"
{
#endif


#include <VTL/publication/text/infra/VTL_publication_text_read.h>
#include <VTL/publication/text/infra/VTL_publication_text_write.h>
#include <VTL/publication/text/VTL_publication_text_op.h>
#include <VTL/publication/text/VTL_publication_text_data.h>


#ifdef __cplusplus
}
#endif


#endif