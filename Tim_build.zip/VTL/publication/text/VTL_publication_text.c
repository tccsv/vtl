#include <VTL/publication/text/VTL_publication_text.h>
